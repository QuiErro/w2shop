<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * 用户状态控制：登录/注册
 * 待修改
 */

class User extends CI_Controller {

}
